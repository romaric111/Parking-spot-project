package graphic2d;
/**
 * 
 * @author Japha Fomen
 *
 */
public class Edge {
	int source, dest, weight;
	 /**
	  * constructeur
	  * @param source
	  * @param dest
	  * @param weight
	  */
    public Edge(int source, int dest, int weight)
    {
        this.source = source;
        this.dest = dest;
        this.weight = weight;
    }
}
