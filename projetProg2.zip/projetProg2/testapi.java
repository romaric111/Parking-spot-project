package graphic2d;

public class testapi {

	public static void main(String[] args) {
		
			projetperform p1=new projetperform();

		
	}

}
