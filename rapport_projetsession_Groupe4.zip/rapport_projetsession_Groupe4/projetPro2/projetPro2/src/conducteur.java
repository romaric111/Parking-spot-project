public class conducteur extends Position {
	/**
	 * @author Japha Fomen
 *@version 1.0
 *@since 2023
	 */
	
	/**
	 * constructeur
	 * @param x
	 * @param y
	 */
conducteur(int x,int y){
	super(x,y);
}
}
