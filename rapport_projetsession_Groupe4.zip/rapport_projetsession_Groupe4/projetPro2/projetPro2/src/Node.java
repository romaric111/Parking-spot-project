
/**
 * 
 * @author Aimeric Tchakounté
 *
 */
class Node
{
    int vertex, weight;
 /**
  * constructeur
  * @param vertex
  * @param weight
  */
    public Node(int vertex, int weight)
    {
        this.vertex = vertex;
        this.weight = weight;
    }
}
